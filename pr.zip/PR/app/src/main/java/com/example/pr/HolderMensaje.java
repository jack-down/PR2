package com.example.pr;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import de.hdodenhof.circleimageview.CircleImageView;

public class HolderMensaje extends RecyclerView.ViewHolder {
    private TextView nombre;
    private TextView mensaje;
    private TextView hora;
    private CircleImageView imagen;

    public HolderMensaje(View itemView) {
        super(itemView);
        nombre = (TextView) itemView.findViewById(R.id.nommensaje);
        mensaje = (TextView) itemView.findViewById(R.id.mensaje);
        hora = (TextView) itemView.findViewById(R.id.horamensaje);
        imagen = (CircleImageView) itemView.findViewById(R.id.fotoperfilMensaje) ;
    }

    public TextView getNombre() {
        return nombre;
    }

    public TextView getMensaje() {
        return mensaje;
    }

    public TextView getHora() {
        return hora;
    }

    public CircleImageView getImagen() {
        return imagen;
    }

    public void setNombre(TextView nombre) {
        this.nombre = nombre;
    }

    public void setMensaje(TextView mensaje) {
        this.mensaje = mensaje;
    }

    public void setHora(TextView hora) {
        this.hora = hora;
    }

    public void setImagen(CircleImageView imagen) {
        this.imagen = imagen;
    }
}
