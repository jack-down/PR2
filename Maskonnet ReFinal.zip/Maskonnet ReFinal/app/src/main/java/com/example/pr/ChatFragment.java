package com.example.pr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatFragment extends AppCompatActivity{

    private CircleImageView foto;
    private TextView nombre;
    private RecyclerView msg;
    private EditText texto;
    private Button enviar;
    private AdapterMensajes adapter;
    private String hora;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_chat);
        foto = (CircleImageView) findViewById(R.id.fotoperfil);
        nombre= (TextView) findViewById(R.id.nomperfil);
        msg = (RecyclerView) findViewById(R.id.rvmessage);
        texto = (EditText) findViewById (R.id.txtmessage);
        enviar = (Button) findViewById (R.id.btnenviar);
        adapter= new AdapterMensajes(this);
        LinearLayoutManager l = new LinearLayoutManager(this);
        msg.setLayoutManager(l);
        msg.setAdapter(adapter);
        hora = sacarHora();

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapter.addMensaje(new Mensaje(texto.getText().toString(),nombre.getText().toString(),"","1",hora));
                texto.getText().clear();
            }
        });

        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                getScrollbar();
            }
        });

    }

    private void getScrollbar(){
        msg.scrollToPosition(adapter.getItemCount()-1);
    }

    public String sacarHora() {
        Date dt = new Date();
        int hours = dt.getHours();
        int minutes = dt.getMinutes();
        String curTime = hours + ":" + minutes;
        return curTime;
    }
}
