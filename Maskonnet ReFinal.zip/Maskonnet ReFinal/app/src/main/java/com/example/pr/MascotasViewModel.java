package com.example.pr;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MascotasViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public MascotasViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Mascotas");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
