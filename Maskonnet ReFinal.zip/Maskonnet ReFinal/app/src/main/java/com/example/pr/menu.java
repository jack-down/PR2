package com.example.pr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class menu extends AppCompatActivity {
    Button chat;
    Button mapa;
    Button mascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        mapa = (Button) findViewById(R.id.mapaBtn);
        chat = (Button) findViewById(R.id.chatBtn);
        mascotas = (Button) findViewById(R.id.mascotasBtn);

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menu.this, ChatFragment.class);
                startActivity(i);
            }
        });
        mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menu.this, MapaFragment.class);
                startActivity(i);
            }
        });
        mascotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menu.this, MascotasFragment.class);
                startActivity(i);
            }
        });
    }
}
