package com.example.pr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

public class MascotasFragment extends Fragment {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        onInflate(R.layout.fragment_mascotas);
    }
}
