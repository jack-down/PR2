package com.example.pr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Reestablecer extends AppCompatActivity {
    Button e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reestablecer);
        e = (Button) findViewById(R.id.rc2);
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Reestablecer.this, Login.class);
                Toast.makeText(Reestablecer.this,"Se ha enviado un correo para reestablecer su contraseña", Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });
    }
}
